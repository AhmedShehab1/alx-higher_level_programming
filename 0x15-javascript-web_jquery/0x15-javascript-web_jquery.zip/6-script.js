$('#update_header').click(function() {
	$('header').text('New Header!!!');
});
