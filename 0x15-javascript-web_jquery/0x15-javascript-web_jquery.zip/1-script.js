$('header').css('color', 'red');

