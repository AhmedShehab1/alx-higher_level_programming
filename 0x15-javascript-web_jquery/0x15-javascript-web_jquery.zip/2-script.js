$('#red_header').on('click', function() {$(this).css('color', 'red');});

