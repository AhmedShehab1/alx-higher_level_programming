document.querySelector('header').style.color = 'red';

