$('#toggle_header').on('click', function() {
       $(this).attr('class', function(i, curr_cls) {
		return curr_cls==='red'?'green':'red';
	});
});
